### AMD Hardware Acceleration Transcoding

Automatically detects and uses AMD CPU and GPU hardware for video transcoding.

#### Features:
- 🔍 Auto-detects AMD CPU and GPU
- 🎛️ Encoding mode selection (Auto/GPU Only/CPU Only)
- ⚡ Supports AMF and VAAPI GPU encoders
- 💻 Optimized CPU software encoding
- 🎬 H.264 and HEVC codec support
- ⚙️ Configurable quality and bitrate settings

#### Encoding Modes:
- **Auto**: Prefer GPU, fallback to CPU (recommended)
- **GPU Only**: Force GPU hardware acceleration (AMF/VAAPI)
- **CPU Only**: Force optimized CPU software encoding

#### Requirements:
- AMD CPU and/or GPU
- FFmpeg with VAAPI/AMF support (included in Jellyfin FFmpeg)
- Linux with proper AMD drivers

---

For more information, see the README.
